document.addEventListener('DOMContentLoaded', function() {
    const noBtn = document.getElementById('noButton');
    const yesBtn = document.getElementById('yesButton');
    const messageElement = document.createElement('div');

    // Fun messages when trying to click No
    const funMessages = [
        "nooo! ",
        "yes dapat HAHA! 😤",
        "dliiiii! 😘",
        "bawaal pisliton! 💝",
        "yes loveee HAHA! 🥰"
    ];

    // Style the message element
    messageElement.style.position = 'fixed';
    messageElement.style.padding = '10px 20px';
    messageElement.style.background = 'rgba(255, 192, 203, 0.9)';
    messageElement.style.borderRadius = '10px';
    messageElement.style.fontFamily = 'Poppins, sans-serif';
    messageElement.style.zIndex = '1000';
    messageElement.style.opacity = '0';
    messageElement.style.transition = 'opacity 0.3s ease';

    document.body.appendChild(messageElement);

    // Function to show message
    function showMessage(message, x, y) {
        messageElement.textContent = message;
        messageElement.style.left = x + 'px';
        messageElement.style.top = y + 'px';
        messageElement.style.opacity = '1';
        
        setTimeout(() => {
            messageElement.style.opacity = '0';
        }, 2000);
    }

    // Handle No button click
    noBtn.addEventListener('click', function(e) {
        // Get random message
        const randomIndex = Math.floor(Math.random() * funMessages.length);
        const message = funMessages[randomIndex];
        
        // Current button position
        const rect = this.getBoundingClientRect();
        
        // Small random movement (20-30 pixels)
        const moveX = 20 + Math.random() * 10;
        const moveY = 20 + Math.random() * 10;
        
        // Randomly decide direction
        const directionX = Math.random() > 0.5 ? 1 : -1;
        const directionY = Math.random() > 0.5 ? 1 : -1;
        
        // Calculate new position
        const newX = rect.left + (moveX * directionX);
        const newY = rect.top + (moveY * directionY);
        
        // Keep button within viewport
        const finalX = Math.min(Math.max(newX, 0), window.innerWidth - rect.width);
        const finalY = Math.min(Math.max(newY, 0), window.innerHeight - rect.height);
        
        // Move button slightly
        this.style.transition = 'all 0.2s ease';
        this.style.position = 'fixed';
        this.style.left = finalX + 'px';
        this.style.top = finalY + 'px';
        
        // Show message
        showMessage(message, rect.left, rect.top - 40);
    });

    // Handle Yes button click
    yesBtn.addEventListener('click', function() {
        // Hide both buttons
        noBtn.style.display = 'none';
        yesBtn.style.display = 'none';
        
        // Show success message
        const successMessage = document.createElement('div');
        successMessage.textContent = 'Yieeee! I love you! 💖';
        successMessage.style.position = 'fixed';
        successMessage.style.top = '50%';
        successMessage.style.left = '50%';
        successMessage.style.transform = 'translate(-50%, -50%)';
        successMessage.style.padding = '20px 40px';
        successMessage.style.background = 'rgba(255, 192, 203, 0.9)';
        successMessage.style.borderRadius = '10px';
        successMessage.style.fontFamily = 'Poppins, sans-serif';
        successMessage.style.fontSize = '24px';
        document.body.appendChild(successMessage);

        // Start confetti
        startConfetti();
    });

    function startConfetti() {
        const duration = 15 * 1000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

        function randomInRange(min, max) {
            return Math.random() * (max - min) + min;
        }

        const interval = setInterval(function() {
            const timeLeft = animationEnd - Date.now();

            if (timeLeft <= 0) {
                return clearInterval(interval);
            }

            const particleCount = 50 * (timeLeft / duration);
            
            confetti(Object.assign({}, defaults, {
                particleCount,
                origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
            }));
            confetti(Object.assign({}, defaults, {
                particleCount,
                origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
            }));
        }, 250);
    }
});
const noBtn = document.querySelector('.no-btn');
const yesBtn = document.querySelector('.yes-btn');
const proposalContent = document.querySelector('.proposal-content');

// Fun messages when trying to click No
const funMessages = [
    "nooo! ",
    "yes dapat HAHA! 😤",
    "dliiiii! 😘",
    "bawaal pisliton! 💝",
    "yes loveee HAHA! 🥰"
];

// Create message element
const messageElement = document.createElement('div');
messageElement.style.cssText = `
    position: fixed;
    color: white;
    font-size: 1.2rem;
    font-family: 'Poppins', sans-serif;
    pointer-events: none;
    transition: all 0.3s ease;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    z-index: 1000;
    background: rgba(255,192,203,0.9);
    padding: 8px 15px;
    border-radius: 20px;
    opacity: 0;
    transform: translateY(0);
`;
document.body.appendChild(messageElement);

let messageIndex = 0;
function showMessage(x, y) {
    messageElement.textContent = funMessages[messageIndex];
    messageElement.style.left = (x - messageElement.offsetWidth/2) + 'px';
    messageElement.style.top = (y - 60) + 'px';
    messageElement.style.opacity = '1';
    messageElement.style.transform = 'translateY(-20px)';
    
    messageIndex = (messageIndex + 1) % funMessages.length;
    
    setTimeout(() => {
        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(-40px)';
    }, 1000);
}

noBtn.addEventListener('mouseover', function(e) {
    // Get current position of the button
    const rect = this.getBoundingClientRect();
    const currentX = rect.left;
    const currentY = rect.top;
    
    // Small movement range (80 pixels in any direction)
    const moveRange = 80;
    
    // Generate random movement within small range of current position
    const randomX = currentX + (Math.random() - 0.5) * moveRange;
    const randomY = currentY + (Math.random() - 0.5) * moveRange;
    
    // Make sure button stays fully visible
    const finalX = Math.min(Math.max(randomX, 20), window.innerWidth - this.offsetWidth - 20);
    const finalY = Math.min(Math.max(randomY, 20), window.innerHeight - this.offsetHeight - 20);
    
    // Add smooth animation
    this.style.transition = 'all 0.2s ease';
    this.style.position = 'fixed';
    this.style.left = finalX + 'px';
    this.style.top = finalY + 'px';
    
    // Show fun message
    showMessage(e.clientX, e.clientY);
});

// Also handle touch events for mobile
noBtn.addEventListener('touchstart', function(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const event = { clientX: touch.clientX, clientY: touch.clientY };
    this.dispatchEvent(new MouseEvent('mouseover', event));
});

yesBtn.addEventListener('click', function() {
    noBtn.style.display = 'none';
    messageElement.style.display = 'none';
    
    proposalContent.innerHTML = `
        <h1 class="title">Yayy!! </h1>
        <p class="proposal-text">Thank you for making me the happiest person! I promise to love you with all my heart.</p>
    `;
    
    const duration = 15 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    function randomInRange(min, max) {
        return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
            return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        
        confetti(Object.assign({}, defaults, { 
            particleCount,
            origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
        }));
        confetti(Object.assign({}, defaults, { 
            particleCount,
            origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
        }));
    }, 250);
});
