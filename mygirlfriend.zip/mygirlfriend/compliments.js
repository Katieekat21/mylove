// Image carousel
let currentImageIndex = 0;
const images = document.querySelectorAll('.carousel-img');
const totalImages = images.length;

function showImage(index) {
    images.forEach(img => img.classList.remove('active'));
    images[index].classList.add('active');
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % totalImages;
    showImage(currentImageIndex);
}

// Auto-advance images every 7 seconds
setInterval(nextImage, 7000);

// Message handling
let currentMessageIndex = 0;
const messages = document.querySelectorAll('.message');
const totalMessages = messages.length;

document.querySelectorAll('.next-message-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if (this.classList.contains('final-message')) {
            // Go to hearts page
            window.location.href = 'hearts.html';
        } else {
            // Show next message
            messages[currentMessageIndex].classList.remove('active');
            currentMessageIndex = (currentMessageIndex + 1) % totalMessages;
            messages[currentMessageIndex].classList.add('active');
        }
    });
});
