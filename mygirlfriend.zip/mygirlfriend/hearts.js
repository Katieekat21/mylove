-document.addEventListener('DOMContentLoaded', () => {
    const instructionPopup = document.getElementById('instructionPopup');
    
    // Show popup when page loads
    instructionPopup.classList.add('show');
    
    // Hide popup when user taps anywhere
    document.addEventListener('click', () => {
        instructionPopup.classList.remove('show');
        
        // Optional: Add a slight delay before starting the game
        setTimeout(() => {
            // Your existing game start logic can go here if needed
        }, 300);
    }, { once: true });
});

const gameContainer = document.getElementById('gameContainer');
const scoreElement = document.getElementById('score');
const progressBar = document.getElementById('progress');
const finalMessage = document.getElementById('finalMessage');

let score = 0;
const targetScore = 10; // Number of hearts needed to proceed
const sweetMessages = [

    "I love you so much! 💖",
    "Gwapaa ka alwayss my lovee!! <33",
    "Alwayss lovee tkaa <33",
    "Kita alwayss haa walay mo hawaa!! <333",
    "You’re my happy place my loveee!! <33",
    "Your smile makes my day. <33", 
    "You’re perfect just the way you are. <33",
    "Every moment with you is a gift. <33", 
    "I’m so lucky to have you LOVEE!! <33",
    "I love you alwayss my gwapaa na cutee lovee",
];

// Prevent too many hearts from spawning at once
let activeHearts = 0;
const maxHearts = 5;

function createHeart() {
    if (score >= targetScore || activeHearts >= maxHearts) return;

    activeHearts++;
    const heart = document.createElement('div');
    heart.className = 'heart';
    heart.innerHTML = '❤️';
    








    // Get viewport dimensions
    const viewportWidth = Math.min(window.innerWidth, document.documentElement.clientWidth);
    const viewportHeight = Math.min(window.innerHeight, document.documentElement.clientHeight);
    
    
    const margin = 50;
    const x = margin + Math.random() * (viewportWidth - margin * 2);
    const y = margin + Math.random() * (viewportHeight - margin * 2);
    
    heart.style.left = x + 'px';
    heart.style.top = y + 'px';
    
    // Random floating animation duration
    const animationDuration = 2 + Math.random() * 2;
    heart.style.animation = `float ${animationDuration}s ease-in-out infinite`;

    // Add both click and touch events
    const catchHeartHandler = (e) => {
        if (e.type === 'touchstart') {
            e.preventDefault(); // Prevent double-firing on mobile
        }
        catchHeart(heart, x, y);
    };

    heart.addEventListener('click', catchHeartHandler);
    heart.addEventListener('touchstart', catchHeartHandler);

    gameContainer.appendChild(heart);

    // Remove heart after some time if not caught
    setTimeout(() => {
        if (heart.parentNode === gameContainer) {
            heart.remove();
            activeHearts--;
            createHeart();
        }
    }, 4000);
}

function showMessage(message, x, y) {
    const popup = document.createElement('div');
    popup.className = 'message-popup';
    popup.textContent = message;
    
    // Position message vertically based on click/touch point
    popup.style.top = (y - 50) + 'px';
    
    // Add to body and start animation
    document.body.appendChild(popup);
    
    // Slight delay to ensure CSS transition works
    requestAnimationFrame(() => {
        popup.classList.add('show');
    });

    // Remove after animation completes (3 seconds + 100ms buffer)
    setTimeout(() => {
        popup.remove();
    }, 3100);
}

function catchHeart(heart, x, y) {
    if (score >= targetScore) return;

    score++;
    scoreElement.textContent = score;
    activeHearts--;
    
    // Update progress bar
    const progress = (score / targetScore) * 100;
    progressBar.style.width = progress + '%';

    // Show sweet message
    showMessage(sweetMessages[score - 1], x, y);

    // Remove the heart with a nice effect
    heart.style.transform = 'scale(1.5)';
    heart.style.opacity = '0';
    setTimeout(() => heart.remove(), 200);

    // Create a new heart after a short delay
    setTimeout(createHeart, 300);

    // Check if game is complete
    if (score >= targetScore) {
        setTimeout(showFinalMessage, 1000);
    }
}

function showFinalMessage() {
    finalMessage.style.display = 'block';
    finalMessage.style.opacity = '0';
    finalMessage.style.transform = 'translate(-50%, -50%) scale(0.9)';
    
    setTimeout(() => {
        finalMessage.style.opacity = '1';
        finalMessage.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 100);
}

// Start the game with initial hearts
for (let i = 0; i < 3; i++) {
    setTimeout(() => createHeart(), i * 300);
}

// Create new hearts periodically
setInterval(() => {
    if (document.querySelectorAll('.heart').length < 3 && score < targetScore) {
        createHeart();
    }
}, 1000);
