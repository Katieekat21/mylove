document.addEventListener('click', () => {
    document.querySelector('.welcome-section').style.opacity = '0';
    setTimeout(() => {
        window.location.href = 'compliments.html';
    }, 1000);
});
