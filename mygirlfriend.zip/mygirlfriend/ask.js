document.addEventListener('DOMContentLoaded', () => {
    const noBtn = document.querySelector('.no-btn');
    const yesBtn = document.querySelector('.yes-btn');
    const message = document.getElementById('message');
    const proposalBox = document.querySelector('.proposal-box');
    let messageTimeout;

    // Function to show message
    function showMessage() {
        message.classList.add('show');
        if (messageTimeout) clearTimeout(messageTimeout);
        messageTimeout = setTimeout(() => {
            message.classList.remove('show');
        }, 3000);
    }

    // Function to move the No button
    function moveButton() {
        // Get button dimensions and position
        const rect = this.getBoundingClientRect();
        const buttonWidth = rect.width;
        const buttonHeight = rect.height;

        // Define maximum movement range (smaller range for closer movement)
        const maxMove = 100; // Maximum pixels to move in any direction

        // Calculate current center position
        const currentX = rect.left + buttonWidth / 2;
        const currentY = rect.top + buttonHeight / 2;

        // Calculate new position within the smaller range
        let newX, newY;
        do {
            // Random movement between -maxMove and +maxMove
            const moveX = (Math.random() - 0.5) * maxMove * 2;
            const moveY = (Math.random() - 0.5) * maxMove * 2;
            
            newX = currentX + moveX;
            newY = currentY + moveY;
        } while (
            // Make sure the button stays within viewport bounds
            newX < buttonWidth || 
            newX > window.innerWidth - buttonWidth ||
            newY < buttonHeight || 
            newY > window.innerHeight - buttonHeight
        );

        // Add some playful rotation (smaller angle for less dramatic movement)
        const rotation = (Math.random() - 0.5) * 40; // Random rotation between -20 and 20 degrees
        
        this.style.position = 'fixed';
        this.style.left = (newX - buttonWidth / 2) + 'px';
        this.style.top = (newY - buttonHeight / 2) + 'px';
        this.style.transform = `rotate(${rotation}deg)`;
        
        showMessage();
    }

    // Add event listeners for No button
    noBtn.addEventListener('mouseover', moveButton);
    noBtn.addEventListener('click', moveButton);
    
    // Create celebration effect
    function createHeart() {
        const heart = document.createElement('div');
        heart.className = 'floating-celebration-heart';
        heart.innerHTML = '💝';
        heart.style.left = Math.random() * 100 + 'vw';
        heart.style.animationDuration = (Math.random() * 3 + 2) + 's';
        document.body.appendChild(heart);
        setTimeout(() => heart.remove(), 5000);
    }

    // Sweet messages for the celebration
    const sweetMessages = [
        "You've made me the happiest person 💖",
        "I promise to love you more each day! 💑",
        "Together forever, my loveee na gwapaa! 💕",
        "My heart is yours, always and forever loveee! 💘",
        "You're my dream come true! ✨",
        "I'm so happy to be your partner! 💑",
        "Thank you loveee for saying YES! Let's create more memories together! i love you alwayss my lovee!! 💑"
    ];

    // Handle Yes button click
    yesBtn.addEventListener('click', () => {
        // Create celebration overlay
        const overlay = document.createElement('div');
        overlay.className = 'celebration-overlay';
        
        const content = document.createElement('div');
        content.className = 'celebration-content';
        
        // Add sweet messages that fade in one after another
        sweetMessages.forEach((msg, index) => {
            setTimeout(() => {
                const msgElement = document.createElement('p');
                msgElement.textContent = msg;
                msgElement.className = 'celebration-message';
                content.appendChild(msgElement);
                msgElement.style.opacity = '1';
            }, index * 2000);
        });

        overlay.appendChild(content);
        document.body.appendChild(overlay);

        // Start heart animation
        let heartInterval = setInterval(createHeart, 200);
        setTimeout(() => clearInterval(heartInterval), 10000);

        // Add buttons after all messages
        setTimeout(() => {
            const buttonContainer = document.createElement('div');
            buttonContainer.className = 'button-container';

            const finalBtn = document.createElement('button');
            finalBtn.textContent = "from beginning 💝";
            finalBtn.className = 'continue-btn';
            finalBtn.onclick = () => {
                window.location.href = 'index.html';
            };

            buttonContainer.appendChild(finalBtn);
            content.appendChild(buttonContainer);
        }, sweetMessages.length * 2000);
    });
});
